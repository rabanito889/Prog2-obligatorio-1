{-#LANGUAGE GADTs #-}
{-# OPTIONS_GHC -fno-warn-missing-methods #-}

{-
FUNDAMENTOS DE COMPUTACIÓN
ENTREGABLE: NÚMEROS ENTEROS

Integrantes del equipo:
Nombre 1: Rodrigo Charamelo Nro Est: 332270
Nombre 2: Rodrigo Carrión  Nro Est: 334254

IMPORTANTE: 
- No se corregirán archivos que no compilen
- Comentar código que no compile y dejar como undefined
- No usar herramientas de IA
-}

module Enteros where

import Naturales

data Signo where { Pos :: Signo ; Neg :: Signo }
    deriving Show

data Entero where { E :: Signo -> N -> Entero }
    deriving Show

--------------------------------------------------------------------------------
-- EJERCICIO 1: Instancia de Eq para Signo
--------------------------------------------------------------------------------
instance Eq Signo where
    (==) = \n -> \m -> case n of{
        Neg -> case m of{
            Neg -> True;
            Pos -> False;
        };
        Pos -> case m of{
            Neg -> False;
            Pos -> True;
        }; 
    }

--------------------------------------------------------------------------------
-- EJERCICIO 2: Instancia de Eq para Entero
-- CUIDADO: E Pos O y E Neg O ambos representan el cero
--------------------------------------------------------------------------------
instance Eq Entero where
    (==) = \e1 -> \e2 -> case e1 of{
        E s1 n1 -> case n1 of{
            O -> case e2 of{
                E s2 n2 -> case n2 of{
                    O -> True;
                    S y -> False;
                };
            };
            S x -> case e2 of{
                E s2 n2 -> s2 == s1 && n1 == n2;
            };
        };
    }

--------------------------------------------------------------------------------
-- EJERCICIO 3: Instancia de Ord para Signo
-- Se pide: Neg < Pos
--------------------------------------------------------------------------------
instance Ord Signo where
    (<=) = \s1 -> \s2 -> case s1 of{
        Pos -> case s2 of{
            Neg -> False;
            Pos -> True;
        };
        Neg -> case s2 of{
            Neg -> True;
            Pos -> True;
        }
    }

--------------------------------------------------------------------------------
-- EJERCICIO 4: Instancia de Ord para Entero
-- Recordar: negativos < cero < positivos
-- Entre negativos: el de mayor magnitud es menor (más alejado de cero)
-- Entre positivos: el de mayor magnitud es mayor
-- CUIDADO: E Pos O y E Neg O ambos representan el cero
--------------------------------------------------------------------------------
instance Ord Entero where
    (<=) = \e1 -> \e2 -> case e1 of{
        E s1 n1 -> case s1 of{
            Pos -> case e2 of{
                E s2 n2 -> case s2 of{
                    Pos -> n1 <= n2;
                    Neg -> case n2 of{
                        O -> n2 == n1;
                        S x -> False;
                    };
                };
                
                
            };
            Neg -> case e2 of{
                E s2 n2 -> case s2 of{
                    Pos -> case n2 of{
                        O -> n2 == n1;
                        S x -> True;
                    };
                    Neg -> n2 <= n1;
                }
            };
        };
    }

--------------------------------------------------------------------------------
-- EJERCICIO 5: Instancia de Num para Entero
-- Definir suma, producto y resta de enteros
-- Recordar las reglas de signos y las diferentes combinaciones
-- Cuando una operación da como resultado cero, se puede devolver E Pos O o E Neg O indistintamente
--------------------------------------------------------------------------------
instance Num Entero where
    (+) = \e1 -> \e2 -> case e1 of{
        E s1 n1 -> case s1 of{
            Pos -> case e2 of{
                E s2 n2 -> case s2 of{
                    Pos -> E Pos (n1 + n2);
                    Neg -> case n1 <= n2 of{
                        True -> E Neg (n2-n1);
                        False -> E Pos (n1 - n2)
                    };       
                };
            };    
            Neg -> case e2 of{
                E s2 n2 -> case s2 of{
                    Pos -> case n2 <= n1 of{
                        True -> E Neg(n1 -n2);
                        False -> E Pos(n2-n1);
                    
                    };
                    Neg -> E Neg(n1 + n2);
                };
            };
            
        };
    }
        
        
        
        
    (*) = \e1 -> \e2 -> case e1 of {
        E s1 n1 -> case s1 of{
            Pos -> case e2 of{
                E s2 n2 -> case s2 of{
                    Pos -> E Pos (n1*n2);
                    Neg -> E Neg (n1*n2);
                };
            };
            Neg -> case e2 of{
                E s2 n2 -> case s2 of{
                    Pos -> E Neg (n1*n2);
                    Neg -> E Pos(n1*n2);
                }
            }
        }
    }
    (-) = \e1 -> \e2 -> case e1 of{
        E s1 n1 -> case s1 of{
            Pos -> case e2 of{
                E s2 n2 -> case s2 of{
                    Pos -> case n1<=n2 of{
                        True -> E Neg (n2 -n1);
                        False -> E Pos (n1 - n2);
                    };
                    Neg -> E Pos (n1 + n2);
                };
            };
            Neg -> case e2 of{
                E s2 n2 -> case s2 of{
                    Neg -> case n1 <= n2 of{
                        True -> E Pos (n2 - n1);
                        False -> E Neg (n1 -n2);
                    };
                    Pos -> E Neg (n1 + n2);
                };
            };
        };
    }
    