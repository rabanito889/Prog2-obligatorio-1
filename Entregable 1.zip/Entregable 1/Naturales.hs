{-#LANGUAGE GADTs #-}
{-# OPTIONS_GHC -fno-warn-tabs #-}
{-# OPTIONS_GHC -fno-warn-missing-methods #-}

module Naturales where
-- Rodrigo Charamelo -332270
data N where { O :: N ; S :: N -> N } deriving Show


uno :: N
uno = S O

dos :: N
dos = S uno
tres :: N
tres = S dos
cuatro :: N
cuatro = S tres
cinco :: N
cinco = S cuatro
predecesor :: N -> N
predecesor = \n -> case n of{O -> O; S x -> x}



instance Eq N where
    (==) :: N -> N -> Bool
    (==) = \n -> \m -> case n of{
        O -> case m of{
            O -> True;
            S y -> False;
        };
        S x -> case m of{
            O -> False;
            S y -> x == y;
        };
    }


instance Ord N where
    (<=) :: N -> N -> Bool
    (<=) = \n -> \m -> case n of{
        O -> True;
        S x -> case m of{
            O -> False;
            S y -> x <=  y;
        }
    }




instance Num N where
    (+) ::  N -> N -> N
    (+) = \n -> \m -> case n of{
        O -> m;
        S x -> S(x + m);
    }

    (*) :: N -> N -> N
    (*) = \n -> \m -> case n of{
        O -> O;
        S x -> m + (x*m);
    }
    (-) :: N -> N -> N
    (-) = \n -> \m -> case n of{
        O -> O;
        S x -> case m of{
            O -> S x;
            S y -> x-y;
        }
    }
